Batch Export
- noch sehr experimentell
- Emptys, Cameras und Lights werden momentan dupliziert in der Szene
